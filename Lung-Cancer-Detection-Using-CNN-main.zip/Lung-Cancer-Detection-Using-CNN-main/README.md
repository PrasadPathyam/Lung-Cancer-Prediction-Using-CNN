# Lung-Cancer-Detection-Using-CNN
This is Lung Cancer Detection using Deep Learning 
We collected data from Kaggle The dataset contains  CT-scan of 
NON-SMALL CELL LUNG CANCER
*Adenocarcinoma
*Large cell carcinoma
*Squamous cell carcinoma
*Normal

Here, the Resnet 50 model is more precise.

dataset link :- https://www.kaggle.com/datasets/mohamedhanyyy/chest-ctscan-images
